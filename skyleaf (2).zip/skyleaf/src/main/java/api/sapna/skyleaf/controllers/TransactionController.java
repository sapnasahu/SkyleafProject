package api.sapna.skyleaf.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import api.sujata.banking.beans.Transaction;
import api.sujata.banking.services.TransactionService;

@RestController
@RequestMapping(value="/api.sujata.banking/v1")
public class TransactionController {

	@Autowired
	TransactionService transactionService;
	
	@GetMapping("/transactions")
	public List findAll()
	{
		return transactionService.findAll();
	}
	@GetMapping("/transactions/{id}")
	public Transaction findById(@PathVariable String id)
	{
		return transactionService.findById(id);
	}
	@PostMapping("/transactions")
	public Transaction saveTransaction(@RequestBody Transaction transaction)
	{
		return transactionService.save(transaction);
	}
}
