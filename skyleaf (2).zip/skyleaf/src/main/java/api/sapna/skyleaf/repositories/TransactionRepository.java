package api.sapna.skyleaf.repositories;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import api.sapna.skyleaf.beans.Transaction;

@Repository
public interface PaymentRepository extends CrudRepository<Transaction,String> {

}
