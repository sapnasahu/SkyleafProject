package api.sapna.skyleaf;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Skyleaftest {

	@Test
	void contextLoads() {
	}

}
